The Warehouse Manager's Playbook — Template Pack (Northline Ops)

This pack companions the playbook:
- New-Hire-Training-Tracker.xlsx — track WHMIS, forklift cert, safety orientation and refreshers
- ROI-Calculator.xlsx — build simple, clear ROI cases and proposals
- Probation-Review-and-PDP-Toolkit.xlsx — monthly probation reviews, then the post-probation development plan
- Playbook-Recurring-Calendar.ics — daily huddles, toolbox talks, weekly and monthly reviews; import into Google Calendar, Apple Calendar, or Outlook
- Playbook-Annual-Operations-Calendar.ics — the yearly rhythm: inventory counts, inspections, peak-season prep, budget and training planning; import into Google Calendar, Apple Calendar, or Outlook

The-Warehouse-Managers-Playbook.pdf is the complete book (29 chapters).
